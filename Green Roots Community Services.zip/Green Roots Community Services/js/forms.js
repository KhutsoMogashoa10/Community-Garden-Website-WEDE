/* forms.js - Green Roots Community Services (Part 3)
Client- side validation + response for enquiry.html and contact.html */

var RECIPIENT_EMAIL = 'info@greenrootscommunityservices.org'; // change to the real address
document.addEventListener('DOMContentLoaded', function() {
    var enquiryForm = document.getElementById('enquiry-form');
    var contactForm = document.getElementById('general-contact-form');
    if (enquiryForm) { initEnquiryForm(enquiryForm); }
    if (contactForm) {initContactForm(contactForm); }
});

/*-------------- Shared helpers -------------- */

//Shows (or clears) an error message under a field. Returns true when the field is valid.
function setError(field, message) {
    var holder = field.closest('div');
    var span = holder.querySelector('.error-message');
    if (!span) {
        span = document.createElement('span');
        span.className = 'error-message';
        span.setAttribute('role', 'alert');
        holder.appendChild(span);
    }

    span.textContent = message;
    if (message) {
        field.classList.add('invalid');
        field.setAttribute('aria-invalid', 'true');

    } else {
        field.classList.remove('invalid');
        field.removeAttribute('aria-invalid');

    }
    return message === '';
}

//Each check returns ' when valid or the error message to show.
var checks = {
    name: function (v) {
        if (v.length < 2) { return 'Please enter your full name (at least 2 characters).';}
        if (!/^[A-Za-z\u00C0-\u024F' -]+$/.test(v)) {return 'Names may only contain letters, hyphens, spaces and apostrophes.';}
        return '';
    },
    email: function (v) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? '' : 'Please enter a valid email address, e.g. name@example.com.';
    },
    phone: function (v) {
        var digits = v.replace(/[\s-]/g, '');
        return /^(\+27|0)[0-9]{9}$/.test(digits) ? '' : 'Enter a valid South African number, e.g. 082 123 4567 or +27 82 123 4567.';
    },
    subject: function (v) {
        return v.length >= 3 && v.length <= 80 ? '' : 'Please enter a subject (3 to 80 characters).';
    },
    message: function (v) {
        if (v.length < 10) { return 'Please write at least 10 characters.'; }
        if (v.length > 500) {return 'Please keep your message under 500 characters.'; }
        return '';
            
        },
        choice: function (v) {
            return v !== '' ? '' : 'Please choose an option.';
    }
};

function validateField(item) {
    var value = item.field.value.trim();
    if(item.optional && value === '') { return setError(item.field, ''); }
    return setError(item.field, item.check(value));
}

//Validates every field (no early exit) and focuses the first invalid one.
function validateAll(items) {
    var allValid = true;
    var firstInvalid = null;
    items.forEach(function (item) {
        if (!validateField(item)) {
            allValid = false;
            if (!firstInvalid) { firstInvalid = item.field; }
        }
    });
    if (firstInvalid) { firstInvalid.focus(); }
    return allValid;
}

function addLiveValidation(items) {
    items.forEach(function (item) {
        item.field.addEventListener('blur', function () { validateField(item); });
    });
}

function addParagraph(parent, text) {
    var p = document.createElement('p');
    p.textContent = text;
    parent.appendChild(p);
}


/* ---------- Enquiry Form ---------- */

var SITES = {
    main:       { name: 'Main Community Garden', days: [1, 2, 3, 4, 5, 6], hours: '07:00 to 17:00'},
    pretoria:   { name: 'Pretoria Garden',       days: [2, 4, 6],          hours: '08:00 to 16:00'}
};

var DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

//Example sponsorship paclages - replace with the organization's real figures.
var PACKAGES = {
    seedling:   { name: 'Seedling Supporter', cost: 500, funds: 'seeds and seedlings for one garden plot for a season'},
    plot:       { name: 'Garden Plot Sponsor', cost: 2500, funds: 'tools, soil and water for one community garden plot for a year'},
    workshop:   { name: 'Workshop Sponsor', cost: 5000, funds: 'one full urban farming workshop including materials for 20 families'}
};

function initEnquiryForm(form) {
    var volunteerBox = document.getElementById('volunteer-fields');
    var sponsorBox = document.getElementById('sponsor-fields');
    var response = document.getElementById('enquiry-response');
    var el = form.elements;

    var baseItems = [ 
        { field: el['full-name'], check: checks.name },
        { field: el['email'],     check: checks.email },
        { field: el['phone'],     check: checks.phone, optional: true },
        { field: el['message'],   check: checks.message}
    ];


    var volunteerItems = [
        { field: el['site'], check: checks.choice },
        { field: el['day'],  check: checks.choice }
    ];

    var sponsorItems = [
        { field: el['package'], check: checks.choice }
    ];

    function currentType() {
        return form.querySelector('input[name="enquiry-type"]:checked').value;
    }

    //Show only the fields that match the chosen enquiry type
    function updateFields() {
        var isVolunteer = currentType() === 'volunteer';
        volunteerBox.classList.toggle('hidden', !isVolunteer);
        sponsorBox.classList.toggle('hidden', isVolunteer);
        response.classList.add('hidden');
    }

    Array.prototype.forEach.call(form.querySelectorAll('input[name="enquiry-type"]'), function (radio) {
        radio.addEventListener('change', updateFields);
    });

    addLiveValidation(baseItems.concat(volunteerItems, sponsorItems));
    updateFields();

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        var type = currentType();
        var items = baseItems.concat(type === 'volunteer' ? volunteerItems : sponsorItems);
        if (!validateAll(items)) {return; }
        showEnquiryResponse(form, type, response);
    });
}

function showEnquiryResponse(form, type, response) {
    var el = form.elements;
    var firstName = el['full-name'].value.trim().split(' ')[0];
    response.textContent = '';

    var heading = document.createElement('h2');
    heading.textContent = 'Thank you, ' + firstName + "!";
    response.appendChild(heading);

    if(type === 'volunteer') {
        var site = SITES[el['site'].value];
        var day = parseInt(el['day'].value, 10);
        if (site.days.indexOf(day) !== -1) {
            addParagraph(response, 'Good news: the ' + site.name + ' is open on ' + DAY_NAMES[day] + 's from ' + site.hours + "." );
            addParagraph(response, 'Volunteering is free. Our volunteer manager will email ' + el['email'].value.trim() + ' within a few days to confirm your first session.');
        } else {
            var openDays = site.days.map(function (d) { return DAY_NAMES[d]; }).join(', ');
            addParagraph(response, 'The ' + site.name + ' is not open on ' + DAY_NAMES[day] + 's. It is open on: ' + openDays + ' (' + site.hours + ').');
            addParagraph(response, 'Please pick one of those days, or choose the other garden, and submit again.');
        }
    } else {
        var pack = PACKAGES[el['package'].value];
        addParagraph(response, 'You chose the ' + pack.name + ' package.');
        addParagraph(response, 'Cost: R' + pack.cost.toLocaleString('en-ZA') + '. This funds ' + pack.funds + '.');
        addParagraph(response, 'We will email ' + el['email'].value.trim() + ' with an invoice and next steps within a few days.');
    }

    response.classList.remove('hidden');
    response.scrollIntoView({ behavior: 'smooth', block: 'nearest'});
}

/* ---------- Contact form --------- */

function initContactForm(form)  {
    var preview = document.getElementById('email-preview');
    var el = form.elements;

    var items = [
        { field: el['contact-name'],    check: checks.name },
        { field: el['contact-email'],   check: checks.email },
        { field: el['contact-phone'],   check: checks.phone, optional: true },
        { field: el['contact-type'],    check: checks.choice },
        { field: el['contact-subject'], check: checks.subject },
        { field: el['contact-message'], check: checks.message }
    ];

    addLiveValidation(items);

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        if (!validateAll(items)) { return; }

        var phone = el['contact-phone'].value.trim() || 'Not provided';
        var subject = '[' + el['contact-type'].value + '] ' + el['contact-subject'].value.trim();
        var body = 'Name: ' + el['contact-name'].value.trim() + '\r\n' + 
                   'Email: ' + el['contact-email'].value.trim() + '\r\n' +
                   'Phone: ' + phone + '\r\n' + 
                   'Message type: ' + el['contact-type'].value + '\r\n\r\n' +
                   el['contact-message'].value.trim();

                   document.getElementById('email-text').textContent = 
                        'To: ' + RECIPIENT_EMAIL + '\nSubject: ' + subject + '\n\n' + body;
                    document.getElementById('send-email-link').href = 
                        'mailto:' + RECIPIENT_EMAIL + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);


                    preview.classList.remove('hidden');
                    preview.scrollIntoView({ behavior: 'smooth', block: 'nearest'});
    });
}

