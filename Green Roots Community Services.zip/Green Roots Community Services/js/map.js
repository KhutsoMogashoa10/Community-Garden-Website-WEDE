/* map.js - leaflet map showing both Green Roots gardens on contact.html */
document.addEventListener('DOMContentLoaded', function () {
    if (!document.getElementById('map-canvas') || typeof L === 'undefined') { return; }

    var map = L.map('map-canvas').setView([-26.0, 28.1], 9);
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 18,
    attribution: 'Tiles &copy; Esri'
}).addTo(map);

    //Approximate coordinates - adjust to the exact street addresses
    var gardens = [
        { name: 'Main Community Garden', address: '122 High Street, Johannesburg', hours: 'Mon to Sat, 07:00 to 17:00', lat: -26.201452, lng: 28.045488 },
        { name: 'Pretoria Garden',       address: '0157, Centurion, Pretoria',     hours: 'Tue, Thu and Sat, 08:00 to 16:00', lat: -25.858458, lng: 28.18961 }
    ];

    var points = [];
    gardens.forEach(function (g) {
        L.marker([g.lat, g.lng]).addTo(map)
            .bindPopup('<strong>' + g.name + '</strong><br>' + g.address + '<br>' + g.hours);
        points.push([g.lat, g.lng]);

    });
    map.fitBounds(points, { padding: [40, 40]}); 

});
